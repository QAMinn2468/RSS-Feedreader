
# Welcome!


In order to run this application, you will need to go to https://qaminn2468.github.io/frontend-nanodegree-feedreader/ .  Open the hamburger icon to view the different RSS feeds.  Click on one to choose it.  Then review the list of entries, clicking on one that interests you.




## Choices

The choices of feed are:

-Navy Times
-Veterans
-Military Family
-Transition




### Options

-Right click to choose to open the entry in a new window.





### Info

This is the fourth project for the Grow with Google Scholarship of the Udacity FEND nanodegree.  Developed by Kim McCaffrey 2018
